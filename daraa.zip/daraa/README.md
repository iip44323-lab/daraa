# 🛡️ درع — Daraa

**منصة الأمن السيبراني العراقية**

## المميزات
- 🔍 فحص المواقع
- 🛡️ حماية الشركات
- 📊 تقارير أمنية
- 🎁 7 أيام مجاناً

## التشغيل المحلي
```bash
pip install -r requirements.txt
uvicorn main:app --reload
